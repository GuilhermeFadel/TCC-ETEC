<?php

include 'conexao_bd.php';  // Certifique-se de que o caminho esteja correto

echo "Conexão bem-sucedida!";

// Fechar a conexão
$conn->close();
?>
